fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'David Brxxwn | Cxmmunity Club'
description 'cxc_supporthub | https://discord.com/invite/EcpCFyX4DC'
version '2.0.0'

shared_scripts {
	"@ox_lib/init.lua",
	"config.lua"
}

client_scripts {
	'client/*.lua'
}

server_scripts {
	'server/*.lua'
}
